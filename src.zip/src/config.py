#client
cli_host = "localhost"
cli_port = 7301

#server
svr_host = "localhost"
svr_port = 7302

#reg
reg_host = "localhost"
reg_port = 7303;

#auth
auth_host = "localhost"
auth_port = 7304

#stor
stor_host = "localhost"
stor_port = 7305

#sync
sync_host = "localhost"
sync_port = 7306