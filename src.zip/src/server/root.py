'''
Created on 2013-3-27

@author: wuzili
'''
import cherrypy
#import os
#import time
import json
import base64
#import random

from util import hash as hash_m
#from util import log
from util import network
import config

import AuthDemo_pb2
    
nMax = 8
k = 5


class Root(object):
    def __init__(self):
        self.sessions = []
        self.sn = 0
        self.stor_connect = network.Connect(config.stor_host, config.stor_port)
        
    def __newsession__(self):
        sid = self.sn
        session = {"sid":sid}
        self.sessions.append(session)
        self.sn += 1
        return sid, session
        
    @cherrypy.expose
    def index(self):
        result = 'Running'
        return result

    @cherrypy.expose
    def regcheck(self, username):
        return self.stor_connect.request("regcheck", username=username))
        
    @cherrypy.expose
    def reg(self, data):
        serializedRequest = base64.urlsafe_b64decode(data)
        request = json.loads(serializedRequest)
        username = request["userName"]
        authdata = request["authdata"]
        n = len(authdata)
        if n > nMax:
            n = nMax
        authdata = []
        for i in range(0,n):
            authdata.append((request.partitionArg[i], request.hashSalt[i], request.keyHash[i]))
        
        
        respond = AuthDemo_pb2.RegCheckRespond()
        respond.status = int(self.stor_connect.request("reg", data=json.dumps({"username": username, "n":n, "k":k, "authdata": authdata})))
        
        return respond.SerializeToString()


    @cherrypy.expose
    def login(self, username):
        data = self.stor_connect.request("login", username=username)
        
        respond = AuthDemo_pb2.AuthQ()
        respond.status = data["status"]
        if respond.status < 0:
            return respond.SerializeToString()
        
        
        qData = data["qData"]
        n = data["n"]
        k = data["k"]
        alist = []
        for partitionArg, hashSalt, keyHash in qData:
            respond.partitionArg.append(partitionArg)
            respond.hashSalt.append(hashSalt)
            alist.append((keyHash))
            
        sid, session = self.__newsession__()
        session["data"] = {"alist":alist, "k":k, "n":n}
        respond.sessionId = sid;
        
        return respond.SerializeToString()
    
    @cherrypy.expose
    def authA(self, data):
        serializedRequest = base64.urlsafe_b64decode(data)
        request = AuthDemo_pb2.AuthA()
        request.ParseFromString(serializedRequest)
        respond = AuthDemo_pb2.AuthRespond()
        
        sid = request.sessionId
        sdata = self.sessions[sid]["data"]
        alist = sdata["alist"]
        n = sdata["n"]
        k = sdata["k"]
        respond.status = -1
        for i in range(0, n):
            r = request.randomSalt[i]
            keyHash = request.keyHash[i]
            a = alist[i]
            if hash_m(r, a) == keyHash:
                k -= 1
                if k <= 0:
                    respond.status = 0
                    break
        return respond.SerializeToString()

def start():
    cherrypy.server.socket_host = config.reg_host
    cherrypy.config.update({'server.socket_port':config.reg_port})
    root = Root()
    cherrypy.quickstart(root)
    
'''
    @cherrypy.expose
    def regnew(self, uname):
        res = json.loads(self.stor_connect.request("regnew", uname=uname, n=n, k=k))
        slist = res["slist"]
        sid, session = self.__newsession__()
        session["data"] = res
        return json.dumps({"sid":sid, "slist":slist})

    @cherrypy.expose
    def regkey(self, sid, hljson):
        kid = self.sessions[sid]["data"]["kid"]
        return self.stor_connect.request("regkey", kid=kid, hljson=hljson)
'''