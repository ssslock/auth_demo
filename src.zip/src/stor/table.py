

class table(object):
    def __init__(self):
        self.keys = {}
        self.count = 0