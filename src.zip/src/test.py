'''

@author: work
'''

import json

t = (1,2,3)
print t
s = json.dumps(t)
print s
t = json.loads(s)
print t
a,b,c = t
print a
print b
print c